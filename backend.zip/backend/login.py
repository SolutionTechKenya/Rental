from flask import Blueprint, request, jsonify
import jwt
import datetime
from database import get_db

# Secret key for JWT
SECRET_KEY = "your_jwt_secret_key"

login_bp = Blueprint('login', __name__)

@login_bp.route('/login', methods=['POST'])
def login():
    db = get_db()
    data = request.json
    username = data.get('username')
    password = data.get('password')

    # Query to check user credentials
    cursor = db.cursor()
    cursor.execute(
        "SELECT id_user, username, roomNo, contact FROM users WHERE username=%s AND password=%s",
        (username, password)
    )
    user = cursor.fetchone()

    if user:
        # Generate JWT token
        token = jwt.encode({
            'id_user': user[0],
            'username': user[1],
            'roomNo': user[2],
            'contact': user[3],
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=1)
        }, SECRET_KEY, algorithm="HS256")

        return jsonify({
            'message': 'Login successful',
            'token': token,
            'user': {
                'id_user': user[0],
                'username': user[1],
                'roomNo': user[2],
                'contact': user[3]
            }
        }), 200
    else:
        return jsonify({'message': 'Invalid credentials'}), 401
