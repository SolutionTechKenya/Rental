import mysql.connector

def get_db():
    # Connect to the database
    db = mysql.connector.connect(
        host="localhost",
        user="root",  # Replace with your MySQL username
        password="",  # Replace with your MySQL password
        database="rent"  # Database name
    )
    return db
